import re, sys
from datetime import datetime, timedelta, timezone
import yaml
from exchangelib import Credentials, Account, Configuration, DELEGATE, NTLM

# ---------- config ----------
def load_cfg(path="config_detect.yaml"):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

# ---------- helpers ----------
def field(txt):  # safe str
    return (txt or "").strip()

def body_text(item):
    try:
        return (item.text_body or item.body or "").strip()
    except Exception:
        return (item.body or "").strip()

def any_substr(haystack: str, needles):
    if not needles: return False
    h = (haystack or "").lower()
    return any((n or "").lower() in h for n in needles if n)

def any_regex(text: str, patterns):
    if not patterns: return False
    for pat in patterns:
        if not pat: continue
        if re.search(pat, text or "", flags=re.I):
            return True
    return False

def pad(s, n):
    s = str(s)
    return s[: n-1] + "…" if len(s) > n else s.ljust(n)

def match_one(pattern, text):
    m = re.search(pattern, text or "", flags=re.I)
    return m.group(1) if m else ""

# ---------- EWS ----------
def connect_ews(e):
    creds = Credentials(username=e["username"], password=e["password"])
    conf  = Configuration(service_endpoint=e["service_endpoint"], credentials=creds, auth_type=NTLM)
    # primary_smtp_address 可用 email 或帳號；這裡用 username 去掉 '網域\'
    ps = e["username"].split("\\")[-1]
    return Account(primary_smtp_address=ps, autodiscover=False, config=conf, access_type=DELEGATE)

def get_folder(acct, path_str):
    f = acct.root / "Top of Information Store"
    for part in (path_str or "INBOX").split("/"):
        if part:
            f = f / part
    return f

# ---------- decision (no Jira side-effect) ----------
def decide(cfg, subj: str, body: str):
    text = f"{subj}\n{body}"

    # A) 先看看有沒有 Jira Key（最強特徵）
    keys = re.findall(cfg["regex"]["issue_key"], text)
    if keys:
        return {"action":"LINK_BY_KEY", "issue_key":keys[0], "priority":"", "reason":"主旨/內文包含 Jira Key"}

    # B) 基於内容做基本抽取與預測（之後接 Jira 搜尋）
    host = match_one(cfg["regex"]["host"], text)
    metric = match_one(cfg["regex"]["metric"], text)
    sev = match_one(cfg["regex"]["severity"], text).lower()
    pri = cfg["maps"]["severity_to_priority"].get(sev, "")

    return {
        "action":"CREATE_OR_SEARCH",
        "issue_key":"",
        "priority": pri,
        "reason": f"告警推測 sev={sev or '-'} host={host or '-'} metric={metric or '-'}"
    }

# ---------- main ----------
def main():
    cfg = load_cfg()
    acct = connect_ews(cfg["exchange"])
    folder = get_folder(acct, cfg["exchange"].get("mailbox"))

    lookback_hours = int(cfg["dryrun"].get("lookback_hours", 24) or 0)
    if lookback_hours > 0:
        since = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
        qs = folder.filter(datetime_received__gt=since).order_by("-datetime_received")
    else:
        qs = folder.all().order_by("-datetime_received")

    items = list(qs)[: cfg["exchange"].get("max_emails_per_run", 100)]

    # 表頭
    print(pad("Date(UTC)", 20), pad("From", 28), pad("Subject", 64),
          pad("Action", 16), pad("Key", 12), pad("Priority", 10), "Reason")
    print("-"*160)

    sk = cfg.get("skip", {})
    for it in items[::-1]:  # 舊→新
        dt   = it.datetime_received.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        frm  = field(getattr(it.sender, "email_address", "")) or field(getattr(it.sender, "name", ""))
        subj = field(it.subject)
        body = body_text(it)

        # ---- 略過規則（只要命中其一就跳過）----
        if any_substr(subj, sk.get("subject_contains")) or any_regex(subj, sk.get("subject_regex")) \
           or any_substr(body, sk.get("body_contains")) or any_regex(body, sk.get("body_regex")) \
           or any_substr(frm,  sk.get("from_contains")):
            print(pad(dt,20), pad(frm,28), pad(subj,64), pad("SKIP",16),
                  pad("",12), pad("",10), "命中 skip 規則")
            continue

        # ---- 沒被略過：進入判斷（之後會接 Jira）----
        result = decide(cfg, subj, body)

        print(pad(dt,20), pad(frm,28), pad(subj,64),
              pad(result["action"],16), pad(result.get("issue_key",""),12),
              pad(result.get("priority",""),10), result.get("reason",""))

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
